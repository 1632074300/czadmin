package com.cz.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import com.cz.Dao.ProductDao;
import com.cz.pojo.Product;
import com.mchange.v2.c3p0.ComboPooledDataSource;

public class ProductDaoimpl implements  ProductDao{

	@Override
	public List<Product> QueryAllProduct() {
		DataSource ds = new ComboPooledDataSource();
		List<Product> list = new ArrayList<Product>();
		Product product = null;
		Connection conn = null;
		PreparedStatement prst = null;
		ResultSet rs = null;
		try {
			conn = ds.getConnection();
			String sql = "select * from product";
			prst = conn.prepareStatement(sql);
			rs = prst.executeQuery();
			while(rs.next()) {
				product = new Product(rs.getInt("pid"), rs.getString("pname"), rs.getDouble("market_price"), rs.getDouble("shop_price"), rs.getString("pimage"), rs.getString("pdate"), rs.getString("pdesc"));
				list.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(prst != null) {
					prst.close();
				}
				if(rs != null) {
					rs.close();
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public int AddProduct(Product product) {
		int s = 0;
		DataSource ds = new ComboPooledDataSource();
		Connection conn =null;
		PreparedStatement prst = null;
		try {
			conn = ds.getConnection();
			String sql = "insert into product(pname,market_price,shop_price,pdesc) values(?,?,?,?)";
			prst = conn.prepareStatement(sql);
			prst.setString(1, product.getPname());
			prst.setDouble(2, product.getMarket_price());
			prst.setDouble(3, product.getShop_price());
			prst.setString(4,product.getPdesc() );
			 s = prst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(prst!=null) {
					prst.close();
				}
				if(conn!=null) {
					conn.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return s;
		
	}

	@Override
	public List<Product> QueryProduct(int id) {
		List<Product> list = new ArrayList<Product>();
		Product product = null;
		DataSource ds = new ComboPooledDataSource();
		Connection conn = null;
		PreparedStatement prst = null;
		try {
			conn = ds.getConnection();
			String sql = "select * from product";
			prst  = conn.prepareStatement(sql);
			ResultSet rs = prst.executeQuery();
			while(rs.next()) {
				product = new Product(rs.getInt("pid"), rs.getString("pname"), rs.getDouble("market_price"), rs.getDouble("shop_price"), rs.getString("pimage"), rs.getString("pdate"), rs.getString("pdesc"));
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	

	@Override
	public int DeleteProduct(int id) {
		int s = 0;
		DataSource ds = new ComboPooledDataSource();
		Connection conn =null;
		PreparedStatement prst = null;
		try {
			conn = ds.getConnection();
			String sql = "delete from product where pid = ?";
			prst = conn.prepareStatement(sql);
			prst.setInt(1, id);
			s = prst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(prst!=null) {
					prst.close();
				}
				if(conn!=null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return s;
	}

	
	
	@Override
	public int UpdateProduct(Product product,int id) {
		int s = 0;
		DataSource ds = new ComboPooledDataSource();
		Connection conn =null;
		PreparedStatement prst = null;
		try {
			conn = ds.getConnection();
			String sql = "update product set pname = ?,market_price = ?,shop_price = ?,pdesc = ? where pid=?";
			prst = conn.prepareStatement(sql);
			prst.setString(1, product.getPname());
			prst.setDouble(2,product.getMarket_price() );
			prst.setDouble(3,product.getShop_price());
			prst.setString(4, product.getPdesc());
			prst.setInt(5, id);
			s = prst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(prst!=null) {
					prst.close();
				}
				if(conn!=null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return s;
	}

	@Override
	public List<Product> Query(int id) {
		DataSource ds = new ComboPooledDataSource();
		List<Product> list = new ArrayList<Product>();
		Product product = null;
		Connection conn = null;
		PreparedStatement prst = null;
		ResultSet rs = null;
		try {
			conn = ds.getConnection();
			String sql = "select * from product where pid=?";
			prst = conn.prepareStatement(sql);
			prst.setInt(1, id);
			rs = prst.executeQuery();
			while(rs.next()) {
				product = new Product(rs.getInt("pid"), rs.getString("pname"), rs.getDouble("market_price"), rs.getDouble("shop_price"), rs.getString("pimage"), rs.getString("pdate"), rs.getString("pdesc"));
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(prst != null) {
					prst.close();
				}
				if(rs != null) {
					rs.close();
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public List<Product> Querykey(String key) {
		DataSource ds = new ComboPooledDataSource();
		List<Product> list = new ArrayList<Product>();
		Product product = null;
		Connection conn = null;
		PreparedStatement prst = null;
		ResultSet rs = null;
		try {
			conn = ds.getConnection();
			String sql = "SELECT * FROM product WHERE pname LIKE '%?%' ";
			prst = conn.prepareStatement(sql);
			rs = prst.executeQuery();
			while(rs.next()) {
				product = new Product(rs.getInt("pid"), rs.getString("pname"), rs.getDouble("market_price"), rs.getDouble("shop_price"), rs.getString("pimage"), rs.getString("pdate"), rs.getString("pdesc"));
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				if(prst != null) {
					prst.close();
				}
				if(rs != null) {
					rs.close();
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
}
