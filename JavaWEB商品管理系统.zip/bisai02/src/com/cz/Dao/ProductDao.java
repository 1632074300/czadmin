package com.cz.Dao;

import java.util.List;

import com.cz.pojo.Product;

public interface ProductDao {
		//查询所有商品
	public List<Product> QueryAllProduct();
	
	//添加商品
	public int AddProduct(Product product);
	
	//根据id查询所有商品
	public List<Product> QueryProduct(int id);
	
	//根据id删除商品
	public int DeleteProduct(int id);
	
	//根据id修改商品信息
	public int UpdateProduct(Product product,int id);
	
	public List<Product> Query(int id);
	
	//关键字查询
	public List<Product> Querykey(String key);
	
	
}
