package com.cz.Service;

import java.util.List;

import com.cz.pojo.Product;

public interface ProductService {
		public List<Product> QueryAllPorduct();
		
		public int AddProduct(Product product);
		
		public List<Product> Queryid(int id);
		
		public int DeleteProduct(int id);
		
		public int UpdateProduct(Product product,int id);
		
		public List<Product> Query(int id);
		
		public List<Product> QueryKey(String key);
}
