package com.cz.Service.impl;

import java.util.List;

import com.cz.Dao.ProductDao;
import com.cz.Dao.impl.ProductDaoimpl;
import com.cz.Service.ProductService;
import com.cz.pojo.Product;

public class ProductServiceimpl implements ProductService {
		ProductDao Dao = new ProductDaoimpl();
	@Override
	public List<Product> QueryAllPorduct() {
		return Dao.QueryAllProduct();
	}
	@Override
	public int AddProduct(Product product) {
		return Dao.AddProduct(product);
		
	}
	@Override
	public List<Product> Queryid(int id) {
		return Dao.QueryProduct(id);
	}
	@Override
	public int DeleteProduct(int id) {
		return Dao.DeleteProduct(id);
	}
	@Override
	public int UpdateProduct(Product product, int id) {
		return Dao.UpdateProduct(product, id);
	}
	@Override
	public List<Product> Query(int id) {
		return Dao.Query(id);
	}
	@Override
	public List<Product> QueryKey(String key) {
		return Dao.Querykey(key);
	}
	

}
