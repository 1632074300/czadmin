package com.cz.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cz.Service.ProductService;
import com.cz.Service.impl.ProductServiceimpl;
import com.cz.pojo.Product;

@WebServlet("/AddProduct")
public class AddProduct extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				request.setCharacterEncoding("UTF-8");
				response.setContentType("text/html; charset=UTF-8");
				
				String pname = request.getParameter("pname");
				Double market_price =Double.parseDouble( request.getParameter("market_price"));
				Double shop_price = Double.parseDouble( request.getParameter("shop_price"));
				String pdesc = request.getParameter("pdesc");
				Product product = new Product(pname, market_price, shop_price, pdesc);
				
				ProductService service = new ProductServiceimpl();
				int s = service.AddProduct(product);
				
				request.getRequestDispatcher("QueryAll").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
