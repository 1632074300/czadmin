package com.cz.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cz.Service.ProductService;
import com.cz.Service.impl.ProductServiceimpl;
import com.cz.pojo.Product;

@WebServlet("/UpdateProduct")
public class UpdateProduct extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//处理客户端响应编码
				request.setCharacterEncoding("utf-8");
				//从前端获取商品id  
				int id =Integer.parseInt(request.getParameter("pid").trim());
				//从前端获取要修改的数据
				String panme = request.getParameter("pname");
				Double market_price = Double.parseDouble(request.getParameter("market_price")) ;
				Double shop_price = Double.parseDouble(request.getParameter("shop_price")) ;
				String pdesc = request.getParameter("pdesc");
				//把数据封装到一个对象中‘
				Product product = new Product(panme, market_price, shop_price, pdesc);
				//拿到serv
				ProductService service = new ProductServiceimpl();
				service.UpdateProduct(product, id);
				//处理服务端响应编码
				response.setContentType("text/html; charset=UTF-8");
				//修改成功从新查询
				request.getRequestDispatcher("QueryAll").forward(request, response);
				
				
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
