package com.cz.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cz.Service.ProductService;
import com.cz.Service.impl.ProductServiceimpl;
import com.cz.pojo.Product;

@WebServlet("/QueryId")
public class QueryId extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//设置请求编码
		request.setCharacterEncoding("utf-8");
		//设置响应编码
		response.setContentType("text/html; charset=UTF-8");
		int id =Integer.parseInt(request.getParameter("pid"));
		//调用service
		ProductService service = new ProductServiceimpl();
		List<Product> product = service.Queryid(id);
		request.setAttribute("product", product);
		
		//因为有数据所以用请求转发
		request.getRequestDispatcher("product_list.jsp").forward(request, response);
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
